import json
import random

from plugins.base import Base


class Plugin(Base):
    """点赞"""
    def __init__(self):
        super().__init__()
        self.ws = None
        self.data = None

    async def send_like(self, qq, times):
        """发送好友赞"""
        ret = {
            'action': 'send_like',
            'params': {
                'user_id': qq,
                'times': times,  # 赞的次数，每个好友每天最多 10 次
            }
        }
        await self.ws.send(json.dumps(ret))

    async def handle(self, message):
        msg = None
        if message == '赞我':
            times = random.randint(1, 10)
            await self.send_like(self.data['user_id'], times)
            msg = f'已为你点赞{times}下'
        return msg
