import base64
import os
import random
import re
import requests

from io import BytesIO

from plugins.base import Base


class Plugin(Base):
    def __init__(self):
        super().__init__()
        self.is_at = True
        self.ats = None
        self.fdir = os.path.dirname(os.path.abspath(__file__))
        self.db = self.load_config()
        self.user_cd = 30
        os.system('pip install pillow')

    @staticmethod
    def get_avatar(qq):
        url = f'https://q.qlogo.cn/headimg_dl?dst_uin={qq}&spec=100'
        r = requests.get(url)
        with open(f'{qq}.png', 'wb') as file:
            file.write(r.content)

    @staticmethod
    def circle(qq):
        from PIL import Image, ImageDraw
        image = Image.open(f'{qq}.png')
        width, height = image.size

        # 假设要裁剪成正圆形，宽度为圆的直径
        radius = min(width, height) // 2  # 选择最小的边作为圆的直径的一半
        center = (width // 2, height // 2)  # 圆心

        # 创建一个新的透明图像作为掩膜
        mask = Image.new('L', (width, height), 0)  # 创建黑色背景，L模式表示灰度图
        draw = ImageDraw.Draw(mask)

        # 画一个白色的圆形
        draw.ellipse((
            center[0] - radius, center[1] - radius,
            center[0] + radius, center[1] + radius), fill=255)

        # 将原图和掩膜合成，得到圆形裁剪后的图像
        result = Image.new('RGBA', (width, height))  # 使用RGBA模式来保留透明通道
        result.paste(image, (0, 0), mask=mask)  # 使用掩膜合成图像

        result.save(f'{qq}.png')

    @staticmethod
    def pa(qq):
        '''爬'''
        from PIL import Image
        image = Image.open(f'{qq}.png')
        width, height = image.size
        new_image = Image.new('RGBA', (width * 9, height))  # 让画布宽度翻倍
        for i in range(6):
            v = (i+1)*30
            rotated_image = image.rotate(-v)
            new_image.paste(rotated_image, (int(i*width*1.5), 0))
        return new_image

    @staticmethod
    def get_img_msg(img, fm='PNG'):
        buffered = BytesIO()
        img.save(buffered, format=fm)
        img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        msg = f'[CQ:image,file=base64://{img_base64}]'
        return msg

    @staticmethod
    def gun(qq):
        from PIL import Image
        image = Image.open(f'{qq}.png')
        width, height = image.size

        images = []
        n = random.choice([6, 9, 12, 15, 18, 30, 36])
        wn = random.choice([3, 6, 9])
        for i in range(n):
            new_image = Image.new('RGB', (width * wn, height))
            v = (i+1)*(180//n)
            rotated_image = image.rotate(-v)
            new_image.paste(rotated_image, (int(i*width*wn/n), 0))
            images.append(new_image)

        images[0].save(
            f'{qq}.gif', save_all=True, append_images=images[1:],
            duration=0, loop=0)

        with open(f'{qq}.gif', 'rb') as img_file:
            img_data = img_file.read()
            img_base64 = base64.b64encode(img_data).decode('utf-8')
        msg = f'[CQ:image,file=base64://{img_base64}]'
        return msg

    @staticmethod
    def change_background(img):
        from PIL import Image
        new_img = Image.new('RGB', img.size, (255, 255, 255))
        new_img.paste(img, (0, 0), img.convert('RGBA').split()[3])
        return new_img

    def papa(self, qq):
        from PIL import Image
        base_imgs = {
            '1.jpg': {'resize': (60, 60), 'paste': (90, 90)},
            '2.jpg': {'resize': (70, 70), 'paste': (150, 48)},
        }

        base_img = random.choice(list(base_imgs.keys()))
        base_img_path = os.path.join(self.fdir, 'img', base_img)
        base = Image.open(base_img_path)
        image = Image.open(f'{qq}.png')
        image = image.resize(base_imgs[base_img]['resize'])
        image = self.change_background(image)
        base.paste(image, base_imgs[base_img]['paste'])
        return base

    async def handle(self, message):
        msg = None
        is_at_me = self.data['is_at_me']
        if is_at_me:
            qq = self.data['self_id']
        else:
            qq = self.data['user_id']
        for at in self.ats:
            re_s = r'qq=(\d+),*'
            info = re.findall(re_s, at)
            qq = int(info[0])
            break
        self.get_avatar(qq)
        self.circle(qq)
        message = message.strip()
        if message == r'\爬':
            img = self.pa(qq)
            msg = self.get_img_msg(img)
        elif message == r'\爬爬':
            msg = self.gun(qq)
        elif message == r'\啪':
            img = self.papa(qq)
            msg = self.get_img_msg(img)
        return msg
