import os

from plugins.base import Base


class Plugin(Base):
    """小牛说话"""
    def __init__(self):
        super().__init__()
        self.is_at = True
        self.fdir = os.path.dirname(os.path.abspath(__file__))
        self.db = self.load_config()
        os.system('pip install python-cowsay')

    def is_match(self, message):
        """检测是否匹配此插件"""
        if message[:2] == '牛说':
            return True
        else:
            return False

    async def handle(self, message):
        msg = message[2:].strip()
        if not msg:
            return
        import random
        from cowsay import cowsay, cowthink

        params = 'bdgpstwy'
        funcs = [cowsay, cowthink]

        func = random.choice(funcs)
        param = random.choice(params)

        msg = func(msg, preset=param)
        msg = msg.replace(' ', '  ')
        return msg
