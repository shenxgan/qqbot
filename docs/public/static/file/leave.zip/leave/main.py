from plugins.base import Base


class Plugin(Base):
    """退群消息通知"""
    def __init__(self):
        super().__init__()
        self.type = 'notice'

    def is_match(self, data):
        """检测是否匹配此插件"""
        if data.get('notice_type') == 'group_decrease':
            return True
        else:
            return False

    async def handle(self, data):
        if data['sub_type'] == 'leave':
            msg = '主动退群'
        else:
            msg = '被踢出群'
        user_id = data['user_id']
        msg = f'{user_id} {msg}'
        return msg
