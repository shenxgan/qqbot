from plugins.base import Base
import requests

class Plugin(Base):
    def __init__(self):
        super().__init__()
        self.type = 'notice'  # 设置类型为notice，因为我们需要处理的是群通知事件

    def is_match(self, data):
        """检测是否匹配此插件"""
        # 检查事件类型是否为群通知，并且提示类型为戳一戳
        return data.get('notice_type') == 'notify' and data.get('sub_type') == 'poke'

    async def call_external_api(self, message):
        url = 'https://api.x.ai/v1/chat/completions'  # 外部API URL
        model = 'grok-vision-beta'
        api_key = '填上你自己的 api key'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}',
        }
        payload = {
            'model': model,
            'messages': [
                {'role': 'user', 'content': message},
            ]
        }
        try:
            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()  # 将触发异常的HTTP错误
            return response.json()['choices'][0]['message']['content']
        except requests.RequestException:
            return None  # 在请求失败时返回None

    async def handle(self, data):
        # 获取被戳者QQ号，即target_id
        target_id = data.get('target_id')
        # 获取收到事件的机器人QQ号，即self_id
        self_id = data.get('self_id')  # 从data参数中获取self_id
        # 检查被戳的目标用户是否是机器人自己
        if target_id == self_id:
            # 构建回复消息
            reply_message = "回复方式"
            external_reply = await self.call_external_api(reply_message)
            return external_reply
        return None  # 如果不是戳一戳事件或者不是戳机器人，则不回复