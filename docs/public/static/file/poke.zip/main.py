from plugins.base import Base
import requests

class Plugin(Base):
    def __init__(self):
        super().__init__()
        self.type = 'notice'  # 设置类型为notice，因为我们需要处理的是群通知事件

    def is_match(self, data):
        """检测是否匹配此插件"""
        # 检查事件类型是否为群通知，并且提示类型为戳一戳
        if data.get('notice_type') == 'notify' and data.get('sub_type') == 'poke':
            return True
        else:
            return False

    async def call_external_api(self, message):
        url = 'https://api.x.ai/v1/chat/completions'  # 外部API URL
        model = 'grok-vision-beta'
        api_key = ''
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}',
        }
        data = {
            'model': model,
            'messages': [
                {'role': 'user', 'content': message},
            ]
        }
        try:
            response = requests.post(url, json=data, headers=headers)
            response.raise_for_status()  # 将触发异常的HTTP错误
            return response.json()['choices'][0]['message']['content']
        except requests.RequestException as e:
            print(f"请求外部API失败：{e}")
            return

    async def handle(self, data):
        # 构建回复消息
        reply_message = ("用俏皮、简洁的语气告诉对方不要再捏啦~。避免使用句号和逗号，并且在需要分隔短语或词语时用空格代替逗号。")  # 这里可以自定义回复的消息内容
        external_reply = await self.call_external_api(reply_message)
        return external_reply