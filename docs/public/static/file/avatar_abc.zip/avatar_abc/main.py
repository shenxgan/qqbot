import os
import random
import re
import requests

from plugins.base import Base


class Plugin(Base):
    def __init__(self):
        super().__init__()
        self.is_at = True
        self.ats = None
        self.data = None
        self.fdir = os.path.dirname(os.path.abspath(__file__))
        self.user_cd = 3
        self.api_key = 'abc-123456'
        self.actions = self.get_avatar_actions()

    def get_avatar_actions(self):
        """头像所有的动作"""
        url = 'https://python-abc.xyz/api/avatar/actions'
        r = requests.get(url)
        return r.json()

    def get_avatar_msg(self, action, qqs, image_url):
        """头像相关的图片处理"""
        url = 'https://python-abc.xyz/api/avatar'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }
        data = {
            'action': action,
            'qqs': qqs,
            'image_url': image_url,
        }
        r = requests.post(url, json=data, headers=headers)
        try:
            img_base64 = r.json()['image']
            msg = f'[CQ:image,file=base64://{img_base64}]'
        except Exception as e:
            print(r.text)
            print(e)
            return
        return msg

    def get_image_msg(self, data):
        """其它图片处理"""
        url = 'https://python-abc.xyz/api/image'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }
        r = requests.post(url, json=data, headers=headers)
        try:
            img_base64 = r.json()['image']
            msg = f'[CQ:image,file=base64://{img_base64}]'
        except Exception as e:
            print(r.text)
            print(e)
            return
        return msg

    def is_match(self, message):
        """检测是否匹配此插件"""
        if message and message[0] == '\\':
            return True
        else:
            return False

    def handle_avatar(self, message):
        msg = None
        qqs = []
        if self.data['is_at_me']:
            qq = self.data['self_id']
            qqs.append(qq)
        for at in self.ats:
            re_s = r'qq=(\d+),*'
            info = re.findall(re_s, at)
            qq = int(info[0])
            if qq not in qqs:
                qqs.append(qq)
        qqs.append(self.data['user_id'])

        # 别名
        nickname = {
            '滚雪球': '雪球',
            '啪': '打脸',
            '撕': '手撕',
            '斩': '砍切',
            '砍': '砍切',
            '切': '砍切',
            '踹': '围殴',
            '拍': '球',
            '剑来': '拔剑',
            '自爆': '激光1',
            '烟花': '激光2',
            '合体': '激光3',
            '摔': '抱摔',
            '菜': '菜狗',
            '生日快乐': '生日',
            '骑': '驾',
            '抓': '捉',
        }

        all_actions = {}
        for item in self.actions:
            action, indexs = item.split('-')
            all_actions[action] = {'action': action, 'indexs': indexs}
        for k, v in nickname.items():
            if v[-1] in '123456789':
                action, indexs = v[:-1], v[-1]
                current_action = {
                    'action': all_actions[action]['action'],
                    'indexs': indexs
                }
            else:
                current_action = all_actions[v]
            all_actions[k] = current_action

        if message[-1] in '123456789':
            _match = message[1:-1]
            _index = message[-1]
        else:
            _match = message[1:]
            _index = None

        if _match in all_actions:
            action = all_actions[_match]['action']
            indexs = all_actions[_match]['indexs']
            if _index is None:
                x = random.choice(indexs)
            elif _index in indexs:
                x = _index
            else:
                return None
            if action == '球':
                if len(qqs) > 2:
                    x = '5'
            elif action == '撅':
                if len(qqs) < 3:
                    qqs.insert(0, self.data['user_id'])
            elif action == '泡脚':
                if len(qqs) > 1:
                    x = len(qqs) - 1
                else:
                    x = 1
                if x >= 5:
                    x = 5
                x = str(x)
            action += x
            image_url, _ = self.get_image_url_from_msg()
            msg = self.get_avatar_msg(action, qqs, image_url)
        return msg

    async def handle(self, message):
        msg = None
        if message == r'\娱乐菜单':
            msgs = [
                ', '.join('啪爬撕斩切吃踢踹踩拍摔赞顶菜打牢盯'),
                ', '.join([
                    '剑来', '自爆', '烟花', '合体', '裂开',
                    '开心', '欢迎', '小丑', '摸鱼'
                ]),
                ', '.join(['滚雪球']),
                r'均以反斜杠开头，示例：\拍',
                '在线使用：https://python-abc.xyz/api/docs'
            ]
            msg = '\n'.join(msgs)
        elif message[:3] == r'\日记':
            data = {'action': '日记', 'text': message[3:].strip()}
            msg = self.get_image_msg(data)
        elif message[:2] in {r'\赏', r'\v', r'\V'}:
            try:
                _num = message[2:]
                if _num[-1] in {'元', '块', '圆'}:
                    _num = _num[:-1]
                if not _num.strip():
                    num = random.randint(1, 2500)
                else:
                    num = int(float(_num))
                    if not (0 < num <= 2500):
                        return
            except Exception:
                return
            data = {'action': 'rmb', 'num': num}
            msg = self.get_image_msg(data)
            msg += f'支付宝到账 {num} 元。'
        else:
            msg = self.handle_avatar(message)
        return msg
