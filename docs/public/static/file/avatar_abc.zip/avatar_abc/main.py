import os
import random
import re
import requests

from plugins.base import Base


class Plugin(Base):
    def __init__(self):
        super().__init__()
        self.is_at = True
        self.ats = None
        self.data = None
        self.fdir = os.path.dirname(os.path.abspath(__file__))
        self.user_cd = 3
        self.api_key = 'abc-123456'

    def get_avatar_msg(self, action, qqs, image_url):
        """头像相关的图片处理"""
        url = 'https://python-abc.xyz/api/avatar'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }
        data = {
            'action': action,
            'qqs': qqs,
            'image_url': image_url,
        }
        r = requests.post(url, json=data, headers=headers)
        try:
            img_base64 = r.json()['image']
            msg = f'[CQ:image,file=base64://{img_base64}]'
        except Exception as e:
            print(r.text)
            print(e)
            return
        return msg

    def get_image_msg(self, data):
        """其它图片处理"""
        url = 'https://python-abc.xyz/api/image'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }
        r = requests.post(url, json=data, headers=headers)
        try:
            img_base64 = r.json()['image']
            msg = f'[CQ:image,file=base64://{img_base64}]'
        except Exception as e:
            print(r.text)
            print(e)
            return
        return msg

    def is_match(self, message):
        """检测是否匹配此插件"""
        if message and message[0] == '\\':
            return True
        else:
            return False

    async def handle(self, message):
        msg = None
        qqs = []
        if self.data['is_at_me']:
            qq = self.data['self_id']
            qqs.append(qq)
        for at in self.ats:
            re_s = r'qq=(\d+),*'
            info = re.findall(re_s, at)
            qq = int(info[0])
            if qq not in qqs:
                qqs.append(qq)
        if not qqs:
            qqs.append(self.data['user_id'])

        if message == r'\娱乐菜单':
            msgs = [
                ', '.join('啪爬撕斩切吃踢踹踩拍摔赞顶菜打牢盯'),
                ', '.join([
                    '剑来', '自爆', '烟花', '合体', '裂开',
                    '开心', '欢迎', '小丑', '摸鱼'
                ]),
                ', '.join(['滚雪球']),
                r'均以反斜杠开头，示例：\拍',
                '在线使用：https://python-abc.xyz/api/docs'
            ]
            msg = '\n'.join(msgs)
            return msg

        actions = [
            {'action': '爬', 'match': {r'\爬'}, 'random': '123456789'},
            {'action': '雪球', 'match': {r'\滚雪球'}, 'random': '12'},
            {'action': '打脸', 'match': {r'\啪'}, 'random': '123456'},
            {'action': '手撕', 'match': {r'\撕'}, 'random': '123'},
            {'action': '砍切', 'match': {r'\斩', r'\砍'}, 'random': '12'},
            {'action': '围殴', 'match': {r'\踹', r'\围殴'}, 'random': '1'},
            {'action': '裂开', 'match': {r'\裂开'}, 'random': '1'},
            {'action': '球', 'match': {r'\拍'}, 'random': '12345'},
            {'action': '拔剑', 'match': {r'\剑来', r'\拔剑'}, 'random': '1'},
            {'action': '激光1', 'match': {r'\自爆'}, 'random': None},
            {'action': '激光2', 'match': {r'\烟花'}, 'random': None},
            {'action': '激光3', 'match': {r'\合体'}, 'random': None},
            {'action': '激光4', 'match': {r'\切'}, 'random': None},
            {'action': '抱摔', 'match': {r'\摔'}, 'random': '123'},
            {'action': '踩', 'match': {r'\踩'}, 'random': '123'},
            {'action': '吃', 'match': {r'\吃'}, 'random': '12345679'},
            {'action': '赞', 'match': {r'\赞'}, 'random': '123'},
            {'action': '踢', 'match': {r'\踢'}, 'random': '123'},
            {'action': '开心', 'match': {r'\开心', r'\赞赞'}, 'random': '123'},
            {'action': '顶', 'match': {r'\顶'}, 'random': '123'},
            {'action': '菜狗', 'match': {r'\菜'}, 'random': '1234'},
            {'action': '打', 'match': {r'\打'}, 'random': '12'},
            {'action': '欢迎', 'match': {r'\欢迎'}, 'random': '12'},
            {'action': '牢', 'match': {r'\牢'}, 'random': '12'},
            {'action': '撅', 'match': {r'\撅'}, 'random': '123'},
            {'action': '盯', 'match': {r'\盯'}, 'random': '123'},
            {'action': '小丑', 'match': {r'\小丑'}, 'random': '123'},
            {'action': '摸鱼', 'match': {r'\摸鱼'}, 'random': '123'},
            {'action': '生日', 'match': {r'\生日', r'\生日快乐'}, 'random': '1'},
            {'action': '嗨起来', 'match': {r'\嗨起来'}, 'random': '123456789'},
        ]
        for item in actions:
            if message[-1] in '123456789':
                _match = message[:-1]
                _index = message[-1]
            else:
                _match = message
                _index = None
            item['match'].add(f'\\{item["action"]}')
            if _match in item['match']:
                if item['random'] is None:
                    x = ''
                elif _index:
                    x = _index
                else:
                    x = random.choice(item['random'])
                action = item['action']
                image_url, _ = self.get_image_url_from_msg()
                if action == '球':
                    if len(qqs) > 1:
                        x = '5'
                elif action == '撅':
                    if len(qqs) < 2:
                        qqs.insert(0, self.data['user_id'])
                elif action == '激光1':
                    qqs = [self.data['user_id']]
                elif action == '打':
                    qqs.append(self.data['user_id'])
                elif action == '吃':
                    if x == '9':
                        action = '恐龙'
                        x = '1'
                action += x
                msg = self.get_avatar_msg(action, qqs, image_url)
                break
        if message[:3] == r'\日记':
            data = {'action': '日记', 'text': message[3:].strip()}
            msg = self.get_image_msg(data)
        elif message[:2] in {r'\赏', r'\v', r'\V'}:
            try:
                _num = message[2:]
                if _num[-1] in {'元', '块', '圆'}:
                    _num = _num[:-1]
                if not _num.strip():
                    num = random.randint(1, 2500)
                else:
                    num = int(float(_num))
                    if not (0 < num <= 2500):
                        return
            except Exception:
                return
            data = {'action': 'rmb', 'num': num}
            msg = self.get_image_msg(data)
            msg += f'支付宝到账 {num} 元。'
        return msg
