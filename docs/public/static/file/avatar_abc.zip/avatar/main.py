import os
import random
import re
import requests

from plugins.base import Base


class Plugin(Base):
    def __init__(self):
        super().__init__()
        self.is_at = True
        self.ats = None
        self.data = None
        self.fdir = os.path.dirname(os.path.abspath(__file__))
        self.user_cd = 3
        self.api_key = 'abc-{不要泄露}'

    def get_avatar_msg(self, action, qqs, image_url):
        """头像相关的图片处理"""
        url = 'https://python-abc.xyz/api/avatar'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }
        data = {
            'action': action,
            'qqs': qqs,
            'image_url': image_url,
        }
        r = requests.post(url, json=data, headers=headers)
        try:
            img_base64 = r.json()['image']
            msg = f'[CQ:image,file=base64://{img_base64}]'
        except Exception as e:
            print(r.text)
            print(e)
            return
        return msg

    def get_image_msg(self, data):
        """其它图片处理"""
        url = 'https://python-abc.xyz/api/image'
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }
        r = requests.post(url, json=data, headers=headers)
        try:
            img_base64 = r.json()['image']
            msg = f'[CQ:image,file=base64://{img_base64}]'
        except Exception as e:
            print(r.text)
            print(e)
            return
        return msg

    async def handle(self, message):
        msg = None
        qqs = []
        if self.data['is_at_me']:
            qq = self.data['self_id']
            qqs.append(qq)
        for at in self.ats:
            re_s = r'qq=(\d+),*'
            info = re.findall(re_s, at)
            qq = int(info[0])
            if qq not in qqs:
                qqs.append(qq)
        if not qqs:
            qqs.append(self.data['user_id'])

        message = message.strip()

        if message == r'\娱乐菜单':
            msgs = [
                ', '.join('啪爬撕斩切吃踢踹踩拍摔赞'),
                ', '.join(['剑来', '自爆', '烟花', '合体', '裂开', '开心']),
                ', '.join(['滚雪球']),
                r'均以反斜杠开头，示例：\拍',
            ]
            msg = '\n'.join(msgs)
            return msg

        actions = [
            {'action': '爬', 'match': {r'\爬'}, 'random': '123456789'},
            {'action': '滚1', 'match': {r'\滚雪球'}, 'random': None},
            {'action': '打脸', 'match': {r'\啪'}, 'random': '123456'},
            {'action': '手撕', 'match': {r'\撕'}, 'random': '123'},
            {'action': '切成两半', 'match': {r'\斩', r'\砍'}, 'random': None},
            {'action': '围殴', 'match': {r'\踹', r'\围殴'}, 'random': None},
            {'action': '裂开', 'match': {r'\裂开'}, 'random': None},
            {'action': '球', 'match': {r'\拍'}, 'random': '12345'},
            {'action': '拔剑', 'match': {r'\剑来', r'\拔剑'}, 'random': None},
            {'action': '激光1', 'match': {r'\自爆'}, 'random': None},
            {'action': '激光2', 'match': {r'\烟花'}, 'random': None},
            {'action': '激光3', 'match': {r'\合体'}, 'random': None},
            {'action': '激光4', 'match': {r'\切'}, 'random': None},
            {'action': '抱摔', 'match': {r'\摔'}, 'random': '1'},
            {'action': '踩', 'match': {r'\踩'}, 'random': '12'},
            {'action': '吃', 'match': {r'\吃'}, 'random': '123'},
            {'action': '赞', 'match': {r'\赞'}, 'random': '12'},
            {'action': '踢', 'match': {r'\踢'}, 'random': '1'},
            {'action': '开心', 'match': {r'\开心', r'\赞赞'}, 'random': None},
        ]
        for item in actions:
            if message in item['match']:
                image_url = None
                x = random.choice(item['random']) if item['random'] else ''
                action = item['action']
                if action in {'手撕', '切成两半', '激光4'}:
                    image_url, _ = self.get_image_url_from_msg()
                if action == '球':
                    if len(qqs) > 1:
                        x = '5'
                elif action == '激光1':
                    qqs = [self.data['user_id']]
                action += x
                msg = self.get_avatar_msg(action, qqs, image_url)
                break
        if message[:3] == r'\日记':
            data = {'action': '日记', 'text': message[3:].strip()}
            msg = self.get_image_msg(data)
        elif message[:2] in {r'\赏', r'\v', r'\V'}:
            try:
                _num = message[2:]
                if _num[-1] in {'元', '块', '圆'}:
                    _num = _num[:-1]
                if not _num.strip():
                    num = random.randint(1, 2500)
                else:
                    num = int(float(_num))
                    if not (0 < num <= 2500):
                        return
            except Exception:
                return
            data = {'action': 'rmb', 'num': num}
            msg = self.get_image_msg(data)
            msg += f'支付宝到账 {num} 元。'
        return msg
