import os
import re
import requests
import time

from plugins.base import Base


class Plugin(Base):
    """A股数据"""
    def __init__(self):
        super().__init__()
        self.is_at = True
        self.fdir = os.path.dirname(os.path.abspath(__file__))
        self.db = self.load_config()
        self.codes = self.load_codes()

    def load_codes(self):
        fpath = os.path.join(self.fdir, 'codes.txt')
        codes = {}
        with open(fpath) as f:
            data = f.read()
        for line in data.split('\n'):
            code, name = line.split(',')
            codes[name] = code
            codes[code[2:]] = code
        return codes

    @staticmethod
    def is_valid_number(s):
        return bool(re.fullmatch(r'[03689]\d{5}', s))

    @staticmethod
    def get_stock_detail(code):
        url = f'https://qt.gtimg.cn/q=s_{code}'
        r = requests.get(url)
        return r.text

    async def handle(self, message):
        code = None
        if message in self.codes:
            code = self.codes[message]
        elif message in self.db['codes']:
            code = self.db['codes'][message]
        elif self.is_valid_number(message):
            pre = {'0': 'sz', '3': 'sz', '6': 'sh', '8': 'bj', '9': 'bj'}
            code = f'{pre[message[0]]}{message}'
        if not code:
            return
        detail = self.get_stock_detail(code)
        info = detail.split('~')
        if len(info) < 5:
            return
        if info[5][0] == '-':
            zd = f'📉 {info[5]}'
        else:
            zd = f'📈 {info[5]}'
        dt = time.strftime('%Y-%m-%d %H:%M:%S')
        content = [
            f'股票名称：{info[1]}',
            f'股票代码：{info[2]}',
            f'当前价格：{info[3]}',
            f'涨跌%：{zd}',
            f'成交量(手)：{info[6]}',
            f'成交额(亿)：{float(info[7]) / 10000}',
            f'时间：{dt}',
        ]
        msg = '\n'.join(content)

        if code[2:] not in self.codes:
            self.db['codes'][info[1]] = code
            self.db['codes'][info[2]] = code
        self.save_config()
        return msg
